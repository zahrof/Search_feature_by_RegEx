import java.util.ArrayList;
import java.util.HashMap;

public class EAutomata {

    public int id;
    public static int counter;
    public boolean terminal;
    public HashMap<Integer, ArrayList<EAutomata>> sons = new HashMap<>();

    public EAutomata(HashMap<Integer, ArrayList<EAutomata>> sons, boolean isFinal){
        this.sons = sons;
        this.terminal = isFinal;
        id = counter;
        counter++;

    }

    public EAutomata(HashMap<Integer, ArrayList<EAutomata>> sons){
        this.sons = sons;
        this.terminal = false;
        id = counter;
        counter++;
    }

    public EAutomata(){
        sons = new HashMap<>();
        terminal = false;
        id = counter;
        counter ++;

    }

    public void put(Integer key, EAutomata a) {
        if (a == null) return;
        ArrayList<EAutomata> all = (ArrayList<EAutomata>) sons.getOrDefault(key, new ArrayList<>()).clone();
        all.add(a);
        sons.put(key, all);
    }

    public void fromRegExTree(RegExTree ret){
        switch (ret.root){
            case RegEx.CONCAT:
                // Creation de la deuxieme partie du chemin
                EAutomata s = new EAutomata((HashMap<Integer, ArrayList<EAutomata>>) sons.clone());

                // Modification des chemins du noeud courant
                sons.clear(); this.put(-1, s);

                // Calcul RegEx R1 dans this puis R2 dans s
                this.fromRegExTree(ret.subTrees.get(0));
                s.fromRegExTree(ret.subTrees.get(1));
                break;
            case RegEx.ALTERN:
                // Creation chemin alternatif R1
                EAutomata s1 = new EAutomata(new HashMap<>());
                EAutomata e1 = new EAutomata((HashMap<Integer, ArrayList<EAutomata>>) sons.clone());
                s1.put(-1, e1); s1.fromRegExTree(ret.subTrees.get(0)); // Liaison + Calcul RegEx R1

                // Creation chemin alternatif R2
                EAutomata s2 = new EAutomata(new HashMap<>());
                EAutomata e2 = new EAutomata((HashMap<Integer, ArrayList<EAutomata>>) sons.clone());
                s2.put(-1, e2); s2.fromRegExTree(ret.subTrees.get(1)); // Liaison + Calcul RegEx R2

                // Modification des chemins du noeud courant
                sons.clear(); this.put(-1, s1); this.put(-1, s2);
                break;
            case RegEx.ETOILE:
                // Creation du chemin optionnel
                EAutomata so = new EAutomata(new HashMap<>());
                EAutomata eo = new EAutomata((HashMap<Integer, ArrayList<EAutomata>>) sons.clone());

                so.put(-1, eo);
                eo.put(-1, so);
                this.put(-1, so);
                so.fromRegExTree(ret.subTrees.get(0));
                break;
            default:
                sons.put(ret.root, sons.remove(-1));
                System.out.println("");
        }
    }

    public static int getCounter(){
        return counter;
    }

    public String toString(){
        if (terminal)
            return "T" + id + sons.toString();
        else
            return id + sons.toString();
    }


}
