public class Couple {
    State a;
    State b;

    public Couple(State a, State b) {
        this.a = a; this.b = b;
    }
}
